<template>
  <div class="card mb-4">
    <div class="card-body">
      <div class="d-flex mb-3">
        <a href="#">
          <img
            src="https://mdbootstrap.com/img/new/avatars/4.jpg"
            alt=""
            style="height: 40px"
            class="rounded-circle border me-2"
          />
        </a>

        <div>
          <a href="" class="text-dark mb-0">
            <strong>Rosie Julio</strong>
          </a>

          <a href="" class="d-block text-muted" style="margin-top: -6px">
            <small>10h</small>
          </a>
        </div>
      </div>

      <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perferendis id
        laboriosam repellendus ut quos iusto! Voluptate magni id nihil ullam.
      </p>
    </div>

    <a href="">
      <img
        src="https://mdbootstrap.com/img/new/standard/city/041.jpg"
        class="w-100"
        alt=""
      />
    </a>

    <div class="card-body">
      <div class="d-flex justify-content-between mb-3">
        <a href="">
          <i class="fas fa-thumbs-up text-primary"></i>
          <span>24</span>
        </a>

        <div>
          <a href="" class="text-muted"> 8 comments </a>
        </div>
      </div>

      <div
        class="d-flex justify-content-between text-center border-top border-bottom mb-4"
      >
        <button class="btn btn-link btn-lg text-muted">
          <i class="fas fa-thumbs-up me-2"></i>Like
        </button>

        <button class="btn btn-link btn-lg text-muted">
          <i class="fas fa-comment me-2"></i>Comment
        </button>
      </div>

      <div class="d-flex mb-3">
        <a href="#">
          <img
            src="../assets/images/myphoto2.jpg"
            alt=""
            style="height: 40px"
            class="rounded-circle border me-2"
          />
        </a>

        <div class="form-outline w-100">
          <textarea
            class="form-control"
            id="textAreaExample"
            rows="2"
          ></textarea>
          <label class="form-label" for="textAreaExample"
            >Write a comment</label
          >
        </div>
      </div>

      <!-- single comment -->
      <div class="d-flex mb-3">
        <a href="#">
          <img
            src="https://mdbootstrap.com/img/new/avatars/4.jpg"
            alt=""
            style="height: 40px"
            class="rounded-circle border me-2"
          />
        </a>

        <div>
          <div
            class="bg-light rounded-lg px-3 py-1"
            style="background-color: #f0f2f5 !important"
          >
            <a href="" class="text-dark mb-0">
              <strong>James Randal</strong>
            </a>
            <a href="" class="d-block text-muted">
              <small
                >Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut,
                sed. Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Facilis, aperiam ab et aspernatur tempora quia magnam id alias
                culpa nulla.</small
              >
            </a>
          </div>

          <a href="" class="text-muted small ms-3 me-2"
            ><strong>Like</strong></a
          >
          <a href="" class="text-muted small ms-2"><strong>Reply</strong></a>
        </div>
      </div>
      <!-- end single comment -->

      <!-- single comment -->
      <div class="d-flex mb-3">
        <a href="#">
          <img
            src="https://mdbootstrap.com/img/new/avatars/5.jpg"
            alt=""
            style="height: 40px"
            class="rounded-circle border me-2"
          />
        </a>

        <div>
          <div
            class="bg-light rounded-lg px-3 py-1"
            style="background-color: #f0f2f5 !important"
          >
            <a href="" class="text-dark mb-0">
              <strong>James Randal</strong>
            </a>
            <a href="" class="d-block text-muted">
              <small>
                amet consectetur adipisicing elit. Facilis, aperiam ab et
                aspernatur tempora quia magnam id alias culpa nulla.</small
              >
            </a>
          </div>

          <a href="" class="text-muted small ms-3 me-2"
            ><strong>Like</strong></a
          >
          <a href="" class="text-muted small ms-2"><strong>Reply</strong></a>
        </div>
      </div>
      <!-- end single comment -->

      <!-- single comment -->
      <div class="d-flex mb-3">
        <a href="#">
          <img
            src="https://mdbootstrap.com/img/new/avatars/6.jpg"
            alt=""
            style="height: 40px"
            class="rounded-circle border me-2"
          />
        </a>

        <div>
          <div
            class="bg-light rounded-lg px-3 py-1"
            style="background-color: #f0f2f5 !important"
          >
            <a href="" class="text-dark mb-0">
              <strong>James Randal</strong>
            </a>
            <a href="" class="d-block text-muted">
              <small
                >Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Facilis, aperiam ab et aspernatur tempora quia magnam id alias
                culpa nulla.</small
              >
            </a>
          </div>

          <a href="" class="text-muted small ms-3 me-2"
            ><strong>Like</strong></a
          >
          <a href="" class="text-muted small ms-2"><strong>Reply</strong></a>
        </div>
      </div>
      <!-- end single comment -->

      <!-- single comment -->
      <div class="d-flex mb-3">
        <a href="#">
          <img
            src="https://mdbootstrap.com/img/new/avatars/7.jpg"
            alt=""
            style="height: 40px"
            class="rounded-circle border me-2"
          />
        </a>

        <div>
          <div
            class="bg-light rounded-lg px-3 py-1"
            style="background-color: #f0f2f5 !important"
          >
            <a href="" class="text-dark mb-0">
              <strong>James Randal</strong>
            </a>
            <a href="" class="d-block text-muted">
              <small
                >Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Facilis, aperiam ab et aspernatur tempora quia magnam id alias
                culpa nulla.</small
              >
            </a>
          </div>

          <a href="" class="text-muted small ms-3 me-2"
            ><strong>Like</strong></a
          >
          <a href="" class="text-muted small ms-2"><strong>Reply</strong></a>
        </div>
      </div>
      <!-- end single comment -->

      <!-- single comment -->
      <div class="d-flex mb-3">
        <a href="#">
          <img
            src="https://mdbootstrap.com/img/new/avatars/8.jpg"
            alt=""
            style="height: 40px"
            class="rounded-circle border me-2"
          />
        </a>

        <div>
          <div
            class="bg-light rounded-lg px-3 py-1"
            style="background-color: #f0f2f5 !important"
          >
            <a href="" class="text-dark mb-0">
              <strong>James Randal</strong>
            </a>
            <a href="" class="d-block text-muted">
              <small
                >Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Facilis, aperiam ab et aspernatur tempora quia magnam id alias
                culpa nulla.</small
              >
            </a>
          </div>

          <a href="" class="text-muted small ms-3 me-2"
            ><strong>Like</strong></a
          >
          <a href="" class="text-muted small ms-2"><strong>Reply</strong></a>
        </div>
      </div>
      <!-- end single comment -->
    </div>
  </div>
</template>
