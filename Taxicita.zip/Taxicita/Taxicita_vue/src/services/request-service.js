const store = async (requestForm) => {
  var token = sessionStorage.getItem("token");
  try {
    const response = await axios.post(
      "http://localhost:8000/api/requests", requestForm,
      {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );
    // handle success
    console.log("Request created:", response.data);
  } catch (error) {
    // handle error
    console.error("Error creating request:", error.response.data);
  }
};

export const requestService = {
  store,
};
