<script>
import AppHeader from "@/components/global/AppHeader.vue";
import { requestService } from "../services/request-service.js";

export default {
  name: "request",
  data() {
    return {
      requestForm: {
        user_id: sessionStorage.getItem("user_id"),
        destination: "",
        location: "",
        city: ""
      },
    };
  },
  components: {
    AppHeader,
    requestService
  },
  methods: {
    handleSubmit() {
      requestService
        .store(this.requestForm)
        .then(() => {
          alert('request created');
        })
        .catch((error) => {
          console.error(error);
        });
    },
  },
};

</script>

<template>

  <div class="request">

    <App-header />

    <div class="container-fluid">
      <div class="row mt-5">
        <div class="col-6 m-auto d-flex flex-column align-items-center">
          <h1 class="fw-bold mb-md-3" style="font-size: 60px">
            Launch a <span style="color: rgba(99, 134, 123, 1)">Request</span>
          </h1>
          <p class="fw-bold">
            <span class="text-danger">Informations</span> to know before you
            make a request
          </p>
        </div>
      </div>

      <div class="row d-flex justify-content-evenly align-items-center pt-4">
        <div
          class="col-3 border border-dark border-1 bg-white d-flex align-items-center justify-content-center pt-md-2"
          style="border-radius: 20px; height: 30px; width: 400px"
        >
          <p class="fw-bold d-flex align-items-center">
            <i class="fas fa-circle-info me-2 pt-1"></i>
            <span class="pt-1" style="font-size: 15px"
              >Your phone number will be visible to the driver</span
            >
          </p>
        </div>

        <div
          class="col-3 border border-dark border-1 bg-white d-flex align-items-center justify-content-center pt-md-2"
          style="border-radius: 20px; height: 30px; width: 400px"
        >
          <p class="fw-bold d-flex align-items-center">
            <i class="fas fa-circle-info me-2 pt-1"></i>
            <span class="pt-1" style="font-size: 15px"
              >Your phone number will be visible to the driver</span
            >
          </p>
        </div>
      </div>

      <div class="row pt-2">
        <div class="col-6 m-auto d-flex flex-column align-items-center">
          <p class="fw-bold">
            For more details,
            <a
              href="#"
              style="color: rgba(99, 134, 123, 1); text-decoration: underline"
              >click here</a
            >
          </p>
        </div>
      </div>

      <div class="row d-flex justify-content-center mt-5">
        <div
          class="col-4 shadow-lg d-flex flex-column align-items-center pt-5 bg-light rounded rounded-3"
          style="height: 350px"
        >
          <form action="" class="d-flex flex-column">
            <div class="row">
              <div class="col-md-6 mb-5">
                <div class="form-outline">
                  <input type="text" id="form3Example1" class="form-control" />
                  <label class="form-label" for="form3Example1"
                    >Select the max time</label
                  >
                </div>
              </div>
              <div class="col-md-6 mb-5">
                <div class="form-outline">
                  <input type="text" id="form3Example2" class="form-control" v-model="requestForm.destination"/>
                  <label class="form-label" for="form3Example2"
                    >Destination</label
                  >
                </div>
              </div>
            </div>

            <div class="form-outline mb-5">
              <input type="text" id="form3Example3" class="form-control" v-model="requestForm.city" />
              <label class="form-label" for="form3Example3"
                >Select the city</label
              >
            </div>

            <div class="row">
              <div class="col-md-6 mb-4">
                <div class="form-outline">
                  <input type="text" id="form3Example1" class="form-control" v-model="requestForm.location"/>
                  <label class="form-label" for="form3Example1"
                    >Neighbourhood</label
                  >
                </div>
              </div>
              <div class="col-md-6 mb-4">
                <div class="form-outline">
                  <input type="text" id="form3Example2" class="form-control" />
                  <label class="form-label" for="form3Example2"
                    >Add specific details</label
                  >
                </div>
              </div>
            </div>

            <button
            type="button"
              class="btn btn-lg fw-bold fs-2 text-light mt-4 align-self-center shadow-lg"
              style="
                background-color: rgba(99, 134, 123, 1);
                width: 350px !important;
              "
              @click="handleSubmit()"
            >
              GO
            </button>
          </form>
        </div>
      </div>
    </div>

  </div>
  
</template>