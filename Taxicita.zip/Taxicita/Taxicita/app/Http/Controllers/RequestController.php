<?php

namespace App\Http\Controllers;

use App\Http\Requests\RequestFormRequest;
use Illuminate\Http\Request;

use App\Models\Requestt;

class RequestController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return Requestt::all();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(RequestFormRequest $request)
    {
        return Requestt::create($request->all());
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        return Requestt::find($id);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request = Requestt::find($id);
        return $request->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        return Requestt::destroy($id);
    }
}
