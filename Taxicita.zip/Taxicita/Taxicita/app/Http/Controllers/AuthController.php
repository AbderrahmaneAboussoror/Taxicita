<?php

namespace App\Http\Controllers;

use App\Http\Requests\AuthFormRequest;
use App\Models\User;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    // register
    public function register(AuthFormRequest $request){

        $fields = $request->all();

        //hash password
        $fields['password'] = bcrypt($fields['password']);

        //register user
        $user = User::create($fields);

        //create token
        $token = $user->createToken('myapptoken')->plainTextToken;

        $response = [
            'user' => $user,
            'token' => $token
        ];

        //send response
        return response($response, 201);
    }

    //logout
    public function logout(){
        auth()->user()->tokens()->delete();
        return [
            'message' => 'Logged out'
        ];
    }

    //sign in
    public function login(Request $request){
        //validate fields
        $fields = $request->validate([
            'email' => 'required',
            'password' => 'required'
        ]);

        //check user
        if(auth()->attempt($fields)){
            //create token
            $token = auth()->user()->createToken('myapptoken')->plainTextToken;
    
            $response = [
                'user' => auth()->user(),
                'token' => $token
            ];
    
            //send response
            return response($response, 201);
        }

    }
}
